
//CHECKSTYLE:OFF
package inginious;



public class Template_RemoveNonLetters {

    //CHECKSTYLE:ON

@    @RemoveNonLetters@@
}


//CHECKSTYLE:OFF
package inginious;



public class Template_isWordPalindrom {
    public static String reverse(String s) {
        return new StringBuilder(s).reverse().toString();
    }

    //CHECKSTYLE:ON

@    @isWordPalindrom@@
}

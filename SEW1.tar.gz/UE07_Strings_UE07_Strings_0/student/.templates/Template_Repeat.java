
//CHECKSTYLE:OFF
package inginious;



public class Template_Repeat {

    //CHECKSTYLE:ON

@    @Repeat@@
}

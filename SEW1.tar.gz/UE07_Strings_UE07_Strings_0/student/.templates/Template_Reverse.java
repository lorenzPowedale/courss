
//CHECKSTYLE:OFF
package inginious;



public class Template_Reverse {

    //CHECKSTYLE:ON

@    @Reverse@@
}

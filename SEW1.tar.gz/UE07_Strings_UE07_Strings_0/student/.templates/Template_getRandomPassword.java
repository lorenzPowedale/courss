
//CHECKSTYLE:OFF
package inginious;



public class Template_getRandomPassword {

    //CHECKSTYLE:ON

@    @getRandomPassword@@
}
